from django import forms
from django.contrib.auth.models import User
from tracker_app.models import UserRegistration,RecordsEfforts,Project

class UserRegistrationForm(forms.ModelForm):
    first_name=forms.CharField(widget=forms.TextInput(attrs={'placeholder':'Firstname','class':'form-control form-control-sm'}))
    last_name=forms.CharField(widget=forms.TextInput(attrs={'placeholder':'Lastname','class':'form-control form-control-sm'}))
    username=forms.CharField(widget=forms.TextInput(attrs={'placeholder':'Username','class':'form-control form-control-sm'}))
    password= forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'Password','class':'form-control form-control-sm'}))

    class Meta():
        model=User
        fields=('first_name','last_name','username','password')

class RecordsEffortsForm(forms.ModelForm):
    # project_name=forms.CharField(max_length=260,widget=forms.TextInput(attrs={'class':'form-control form-control-sm'}))
    project_name=forms.ModelChoiceField(queryset=Project.objects.all(), empty_label='Select Project',widget=forms.Select(attrs={'class':'form-control'}))
    task_name=forms.CharField(max_length=260,widget=forms.TextInput(attrs={'class':'form-control form-control-sm'}))
    work_done=forms.CharField(widget=forms.Textarea(attrs={'class':'form-control form-control-sm form-control-textarea'}))
    work_date=forms.DateField(widget=forms.widgets.DateInput(attrs={'type': 'date','class':'form-control form-control-date'}))
    work_hours=forms.CharField(max_length=4,widget=forms.NumberInput(attrs={'class':'form-control form-control-sm' ,'data-toggle':'tooltip','title':'Enter upto 1 decimal only e.g., 1 or 8.5'}))
    work_issue=forms.CharField(widget=forms.Textarea(attrs={'class':'form-control form-control-sm form-control-textarea','data-toggle':'tooltip','title':'Please enter "none" if no value'}))
    other_issue=forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control form-control-sm form-control-textarea','data-toggle':'tooltip','title':'Please enter "none" if no value'}))

    class Meta():
        model=RecordsEfforts
        exclude=('user_name',)

class ViewUserEffortForm(forms.ModelForm):
    user_name=forms.ModelChoiceField(queryset=User.objects.all(), empty_label='Select Staff',widget=forms.Select(attrs={'class':'form-control'}))

    class Meta():
        model=RecordsEfforts
        fields=('user_name',)
