from django.contrib import admin
from tracker_app.models import UserRegistration,RecordsEfforts,Project

# Register your models here.
admin.site.register(UserRegistration)
admin.site.register(RecordsEfforts)
admin.site.register(Project)
