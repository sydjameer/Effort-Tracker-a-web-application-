from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class UserRegistration(models.Model):
    def __init__(self):
        user=models.OneToOneField(User)

    def __str__(self):
        return self.user.username

class Project(models.Model):
    project_name=models.CharField(max_length=260,unique=True)

    def __str__(self):
        return self.project_name

class RecordsEfforts(models.Model):
    user_name=models.ForeignKey(User, on_delete=models.CASCADE)
    project_name=models.CharField(max_length=260)
    # project_name=models.ForeignKey(Project, on_delete=models.CASCADE,to_field="project_name")
    task_name=models.CharField(max_length=260)
    work_done=models.TextField(null=True)
    work_date=models.DateField()
    work_hours=models.DecimalField(max_digits=2, decimal_places=1)
    work_issue=models.TextField(null=True,blank=True)
    other_issue=models.TextField(null=True,blank=True)
